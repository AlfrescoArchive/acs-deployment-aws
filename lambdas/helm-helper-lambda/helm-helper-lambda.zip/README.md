# An AWS Lambda function written in Python with helper functions for ACS Helm Deployments

# Pre-requisites
* Python 2.7
* Boto3

# Run Lambda function from local host
* ..to do..

# Upload lambda in ACS Deployment s3 bucket
* ..to do.. 
